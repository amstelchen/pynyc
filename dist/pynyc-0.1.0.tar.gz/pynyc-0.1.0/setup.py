# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pynyc']

package_data = \
{'': ['*']}

install_requires = \
['arrow>=1.2.3,<2.0.0', 'python-gettext>=4.0,<5.0', 'pytz>=2022.7,<2023.0']

entry_points = \
{'console_scripts': ['pynyc = pynyc.__main__:main']}

setup_kwargs = {
    'name': 'pynyc',
    'version': '0.1.0',
    'description': "A New Years's Clock",
    'long_description': "[![Documentation Status](https://readthedocs.org/projects/pynyc/badge/?version=latest)](https://pynyc.readthedocs.io/en/latest/?badge=latest) [![Python package](https://github.com/amstelchen/pynyc/actions/workflows/python-package-no-pytest.yml/badge.svg)](https://github.com/amstelchen/pynyc/actions/workflows/python-package-no-pytest.yml)\n\n<h1>PyNYC</h1>\n\n#### A New Years's Clock\n\nTODO\n\n#### What is it *not*?\n\nTODO\n\n#### Usage\n\n```\nusage: PyNYC [-h] [-fg FG] [-bg BG] [-v]\n\nA New Years's Clock\n\noptions:\n  -h, --help     show this help message and exit\n  -fg FG         foreground (text) color\n  -bg BG         background (wall) color\n  -v, --version  show program's version number and exit\n```\n\n#### Installation\n\nSteps assume that `python` (>= 3.8) and `pip` are already installed.\n\nInstall dependencies (see sections below)\n\nThen, run:\n\n    $ pip install pynyc\n\nInstall directly from ``github``:\n\n\n    $ pip install git+https://github.com/amstelchen/pynyc#egg=GameInfo\n\nWhen completed, run it with:\n\n    $ pynyc\n\n#### Configuration\n\nThe package contains a sample configuration, `pynyc.conf.sample` which can be copied to `~/.config/pynyc.conf`. It will then be read to use its settings instead of *pynyc*'s built-in.\n\n```\nfg = white\nbg = black\nfontface = Courier\nfontsize = 50\nscreensaver = 1\nalarm = 60, 15, 1\n```\n\n#### Dependencies\n\nOn Debian-based distributions (Mint, Ubuntu, MX, etc.), installation of the packages `tk` and `python3-tk` may be necessary.\n\n    $ sudo apt install python3-tk tk\n\nOn Arch based distributions, only tk needs to be installed.\n\n    $ sudo pacman -S tk\n\nOn Void Linux, installation of the package `python3-tkinter`is necessary instead.\n\n    $ sudo xbps-install python3-tkinter\n\nAnyways, it often helps to keep your python installation updated:\n\n    $ python -m pip install --upgrade pip wheel setuptools\n\n#### System requirements\n\n*pynyc* is tested to work on the following distributions:\n\nTODO\n\n#### Reporting bugs\n\nIf you encounter any bugs or incompatibilities, __please report them [here](https://github.com/amstelchen/pynyc/issues/new)__.\n\n\n#### Enabling logging/debugging\n\n```\n$ pynyc --verbose\n2022-06-09 01:42:43.612974 DEBUG: ... 1.0.12\n\n```\n\n#### Licences\n\n*pynyc* is licensed under the [GPLv2](LICENSE) license.\n",
    'author': 'Michael John',
    'author_email': 'michael.john@gmx.at',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
